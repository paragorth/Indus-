# Indus Script Analysis — Frozen Reproducibility Package

## Contents
- `data/` — raw source data, unmodified (SQL dump, CISI corpus JSON, feature descriptions, cross-coding bridge)
- `scripts/run_all.py` — single entry point; regenerates every number cited in both papers
- `output/results.json` — machine-readable output (165 keys), `output/results.md` — human-readable
- `AUDIT_REPORT.md` — reproducibility check log, one discrepancy found and fixed

## To reproduce
```
cd scripts
python3 run_all.py
```
Requires: numpy. No other dependencies. Runtime ~2-3 minutes.
Every number in `results.json` should match the previous run up to Monte Carlo
noise (different random seeds per execution; magnitude of expected drift is
~0.002-0.005 on penalty estimates at 100 splits). Any larger discrepancy
indicates either a code change or a bug and should be investigated before
trusting manuscript numbers.

## Data provenance
- `population-script.sql`: github.com/yajnadevam/indus-website (commit at time of download)
- `cisi_corpus/`, `cisi_features/`: github.com/mayig/indus-valley-script-corpus
- `bridge.json`: derived cross-coding table between the two above, built by aligning
  140 shared Mohenjo-daro seals (see Paper A Section 2 for method)

## Manuscripts
Both papers cite only values present in `output/results.json`. If you find a
manuscript number that is not traceable to a key in that file, it is a bug —
please report it.
