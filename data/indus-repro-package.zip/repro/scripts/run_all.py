#!/usr/bin/env python3
"""
FROZEN REPRODUCIBILITY PIPELINE
Indus Script Heterogeneity & Functional Sign Class Analysis
Parag Garg, 2026

Single entry point. Run as:  python3 run_all.py
Reads only from ../data/ (raw, unmodified sources).
Writes all numbers to ../output/results.json and ../output/results.md
Every number cited in Paper A and Paper B must trace to a key in results.json.

No manual editing of outputs. No hand-copied numbers. If a manuscript number
does not appear here, it is not yet reproducible and should not be cited.
"""
import re, random, math, json, os
import numpy as np
from collections import Counter, defaultdict

random.seed(0)  # top-level determinism; sub-analyses use documented derived seeds
DATA = os.path.join(os.path.dirname(__file__), '..', 'data')
OUT  = os.path.join(os.path.dirname(__file__), '..', 'output')
os.makedirs(OUT, exist_ok=True)

RESULTS = {}  # every reportable number lands here, flat-namespaced

def record(key, value):
    if key in RESULTS:
        raise RuntimeError(f"duplicate result key: {key}")
    RESULTS[key] = value
    return value

# ============================================================
# 1. LOAD RAW DATA
# ============================================================
sql = open(os.path.join(DATA, 'population-script.sql')).read()

def sql_rows(table):
    m = re.search(r'INSERT INTO ' + table + r'[^;]*?VALUES(.*?);', sql, re.S | re.I)
    return re.findall(r'\(([^()]*)\)', m.group(1)) if m else []

seal_site = {}
for r in sql_rows('SEAL'):
    p = [x.strip().strip('"') for x in r.split(',')]
    seal_site[int(p[0])] = p[1]

site_name = {}
for r in sql_rows('SITE'):
    p = [x.strip().strip('"') for x in r.split(',')]
    if len(p) >= 2:
        site_name[p[0]] = p[1]

icon = set()
iconlab = {}
m = re.search(r'INSERT INTO ICONOGRAPHY\(SEALID[^;]*?VALUES(.*?);', sql, re.S)
for r in re.findall(r'\(([^()]*)\)', m.group(1)):
    p = r.split(',', 1)
    icon.add(int(p[0]))
    iconlab[int(p[0])] = p[1].strip().strip('"').lower()

seq = defaultdict(dict)
for r in sql_rows('GLYPHSEQUENCE'):
    s, g, i = [int(x) for x in r.split(',')]
    seq[s][i] = g

FOREIGN_SITES = {'Gonur Depe', 'Altyn Depe', 'Salut', 'Failaka', 'Ur', 'Kish', 'Susa', 'Nippur', 'Bahrain'}

# Direction correction: stored order is reversed reading order (documented finding;
# verified via positional fingerprint of modal sign + object-level photographic check).
# We apply the reversal here, once, as the single source of truth.
ALL_RECORDS = []  # (seal_id, site, text_in_reading_order)
seen_seq = set()
for s, d in seq.items():
    raw = [d[i] for i in sorted(d)]
    t = tuple(reversed(raw))  # DIRECTION CORRECTION APPLIED HERE
    if len(t) < 2:
        continue
    st = site_name.get(seal_site.get(s, ''), '?')
    ALL_RECORDS.append((s, st, t))

record('corpus.total_objects_with_sequences', len(ALL_RECORDS))
record('corpus.distinct_sites', len(set(st for _, st, _ in ALL_RECORDS)))

# Deduplicated (exact sequence identity), home region only
seen = set()
HOME = []
FOREIGN = []
for s, st, t in ALL_RECORDS:
    if t in seen:
        continue
    seen.add(t)
    if st in FOREIGN_SITES:
        FOREIGN.append((s, st, t))
    else:
        HOME.append((s, st, t))

record('corpus.home_deduped_n', len(HOME))
record('corpus.foreign_deduped_n', len(FOREIGN))

Mse = [t for s, st, t in HOME if st == 'Mohenjo-daro' and s in icon]
Mno = [t for s, st, t in HOME if st == 'Mohenjo-daro' and s not in icon]
Hse = [t for s, st, t in HOME if st == 'Harappa' and s in icon]
FT = [t for s, st, t in FOREIGN]

record('corpus.mohenjodaro_seals_n', len(Mse))
record('corpus.mohenjodaro_nonseals_n', len(Mno))
record('corpus.harappa_seals_n', len(Hse))
record('corpus.foreign_texts_n', len(FT))

# ============================================================
# 2. AGGREGATE VALIDATION (vs published Mahadevan/EBUDS statistics)
# ============================================================
alltexts_full = [tuple(reversed([d[i] for i in sorted(d)])) for d in seq.values()]
tok = Counter(s for t in alltexts_full for s in t)
N = sum(tok.values())
ranked = tok.most_common()
record('validation.total_tokens', N)
record('validation.distinct_signs', len(tok))
record('validation.mean_text_length', round(N / len(alltexts_full), 3))
record('validation.top_sign_share_pct', round(100 * ranked[0][1] / N, 1))
cum, k = 0, 0
for sgn, c in ranked:
    cum += c
    k += 1
    if cum / N >= 0.80:
        break
record('validation.signs_for_80pct_coverage', k)
begin = Counter(t[0] for t in alltexts_full if len(t) >= 2)
end = Counter(t[-1] for t in alltexts_full if len(t) >= 2)
def top10share(c):
    tot = sum(c.values())
    return sum(v for _, v in c.most_common(10)) / tot
record('validation.ender_top10_share_pct', round(100 * top10share(end), 1))
record('validation.beginner_top10_share_pct', round(100 * top10share(begin), 1))

# ============================================================
# 3. CORE MARKOV / CROSS-PREDICTION MACHINERY (Paper A)
# ============================================================
def fit_markov(T):
    I = Counter(); Tr = defaultdict(Counter)
    for t in T:
        I[t[0]] += 1
        for a, b in zip(t, t[1:]):
            Tr[a][b] += 1
    return I, Tr

def cross_entropy(model, T, V, alpha=0.5):
    I, Tr = model
    It = sum(I.values())
    tot, n = 0.0, 0
    for t in T:
        tot += -math.log((I.get(t[0], 0) + alpha) / (It + alpha * V)); n += 1
        for x, y in zip(t, t[1:]):
            at = sum(Tr.get(x, {}).values()) if x in Tr else 0
            c = Tr.get(x, {}).get(y, 0) if x in Tr else 0
            tot += -math.log((c + alpha) / (at + alpha * V)); n += 1
    return tot, n

def penalty(A, B, seed, alpha=0.5, shared_vocab=False):
    r = random.Random(seed)
    A = A[:]; B = B[:]; r.shuffle(A); r.shuffle(B)
    ha, hb = int(0.8 * len(A)), int(0.8 * len(B))
    Atr, Ate = A[:ha], A[ha:]
    Btr, Bte = B[:hb], B[hb:]
    if shared_vocab:
        sv = {s for t in Atr for s in t} & {s for t in Btr for s in t}
        f = lambda T: [tuple(s for s in t if s in sv) for t in T]
        Atr, Ate, Btr, Bte = [[x for x in f(X) if len(x) >= 2] for X in (Atr, Ate, Btr, Bte)]
    V = len({s for t in Atr + Btr for s in t}) + 1
    mA = fit_markov(Atr); mB = fit_markov(Btr)
    oa, na = cross_entropy(mA, Ate, V, alpha)
    ob, nb = cross_entropy(mB, Bte, V, alpha)
    ca, _ = cross_entropy(mB, Ate, V, alpha)
    cb, _ = cross_entropy(mA, Bte, V, alpha)
    dAB = (ca - oa) / na
    dBA = (cb - ob) / nb
    sym = (na * dAB + nb * dBA) / (na + nb)
    return sym, dAB, dBA

def battery(A, B, key_prefix, nrep=100, nperm=499, alpha=0.5, shared_vocab=False):
    res = [penalty(A, B, s, alpha, shared_vocab) for s in range(nrep)]
    syms = [r[0] for r in res]
    obs = float(np.mean(syms))
    record(f'{key_prefix}.penalty_mean', round(obs, 4))
    record(f'{key_prefix}.penalty_ci_lo', round(float(np.percentile(syms, 2.5)), 4))
    record(f'{key_prefix}.penalty_ci_hi', round(float(np.percentile(syms, 97.5)), 4))
    record(f'{key_prefix}.dir_AB_mean', round(float(np.mean([r[1] for r in res])), 4))
    record(f'{key_prefix}.dir_BA_mean', round(float(np.mean([r[2] for r in res])), 4))
    pool = A + B
    rng = random.Random(77)
    exceed = 0
    for i in range(nperm):
        rng.shuffle(pool)
        r = penalty(pool[:len(A)], pool[len(A):], i, alpha, shared_vocab)
        if r[0] >= obs:
            exceed += 1
    record(f'{key_prefix}.perm_exceedances', exceed)
    record(f'{key_prefix}.perm_n', nperm)
    record(f'{key_prefix}.perm_p', round((exceed + 1) / (nperm + 1), 5))
    return obs

# --- Register effect ---
battery(Mse, Mno, 'paperA.register_base', nrep=100)

# --- Register, training-size matched ---
capsize = int(0.8 * len(Mno))
def penalty_capped(A, B, seed, cap, alpha=0.5):
    r = random.Random(seed)
    A = A[:]; B = B[:]; r.shuffle(A); r.shuffle(B)
    ha, hb = int(0.8 * len(A)), int(0.8 * len(B))
    Atr, Ate = A[:ha][:cap], A[ha:]
    Btr, Bte = B[:hb], B[hb:]
    V = len({s for t in Atr + Btr for s in t}) + 1
    mA = fit_markov(Atr); mB = fit_markov(Btr)
    oa, na = cross_entropy(mA, Ate, V, alpha); ob, nb = cross_entropy(mB, Bte, V, alpha)
    ca, _ = cross_entropy(mB, Ate, V, alpha); cb, _ = cross_entropy(mA, Bte, V, alpha)
    dAB = (ca - oa) / na; dBA = (cb - ob) / nb
    return (na * dAB + nb * dBA) / (na + nb), dAB, dBA
res = [penalty_capped(Mse, Mno, s, capsize) for s in range(100)]
record('paperA.register_sizematched.penalty_mean', round(float(np.mean([r[0] for r in res])), 4))
record('paperA.register_sizematched.penalty_ci_lo', round(float(np.percentile([r[0] for r in res], 2.5)), 4))
record('paperA.register_sizematched.penalty_ci_hi', round(float(np.percentile([r[0] for r in res], 97.5)), 4))
record('paperA.register_sizematched.dir_AB_mean', round(float(np.mean([r[1] for r in res])), 4))
record('paperA.register_sizematched.dir_BA_mean', round(float(np.mean([r[2] for r in res])), 4))

# --- Site effect (base, shared-vocab) ---
battery(Mse, Hse, 'paperA.site_base', nrep=100)
battery(Mse, Hse, 'paperA.site_sharedvocab', nrep=100, shared_vocab=True)

# --- Site effect: unigram-only decomposition ---
def unigram_penalty(A, B, seed, alpha=0.5):
    r = random.Random(seed); A = A[:]; B = B[:]; r.shuffle(A); r.shuffle(B)
    ha, hb = int(0.8 * len(A)), int(0.8 * len(B))
    Atr, Ate = A[:ha], A[ha:]; Btr, Bte = B[:hb], B[hb:]
    V = len({s for t in Atr + Btr for s in t}) + 1
    cA = Counter(s for t in Atr for s in t); cB = Counter(s for t in Btr for s in t)
    def xh(c, T):
        tot = sum(c.values()); s = 0; n = 0
        for t in T:
            for x in t:
                s += -math.log((c.get(x, 0) + alpha) / (tot + alpha * V)); n += 1
        return s, n
    oa, na = xh(cA, Ate); ob, nb = xh(cB, Bte)
    ca, _ = xh(cB, Ate); cb, _ = xh(cA, Bte)
    dAB = (ca - oa) / na; dBA = (cb - ob) / nb
    return (na * dAB + nb * dBA) / (na + nb)
uni = [unigram_penalty(Mse, Hse, s) for s in range(60)]
record('paperA.site_unigram_only.penalty_mean', round(float(np.mean(uni)), 4))

# ============================================================
# 4. FOREIGN TEXT SURPRISAL (Paper A, per-text design)
# ============================================================
random.seed(9)
Hshuf = HOME[:]  # (s, st, t)
Htexts = [t for _, _, t in Hshuf]
random.shuffle(Htexts)
tr, te = Htexts[:1700], Htexts[1700:]
V = len({s for t in tr for s in t}) + 1
mod = fit_markov(tr)
It = sum(mod[0].values())
def surprisal(t, alpha=0.5):
    I, Tr = mod
    s = -math.log2((I.get(t[0], 0) + alpha) / (It + alpha * V)); n = 1
    for x, y in zip(t, t[1:]):
        at = sum(Tr.get(x, {}).values()) if x in Tr else 0
        s += -math.log2(((Tr.get(x, {}).get(y, 0) if x in Tr else 0) + alpha) / (at + alpha * V)); n += 1
    return s / n
hs = [surprisal(t) for t in te]
fs = [surprisal(t) for t in FT]
record('paperA.foreign.n_home_heldout', len(hs))
record('paperA.foreign.n_foreign', len(fs))
record('paperA.foreign.mean_diff_bits', round(float(np.mean(fs) - np.mean(hs)), 3))
allv = fs + hs; labs = [1]*len(fs) + [0]*len(hs)
obs = np.mean(fs) - np.mean(hs)
rng = random.Random(4); exceed = 0; NP = 9999
for _ in range(NP):
    rng.shuffle(labs)
    f_ = [v for v, l in zip(allv, labs) if l]; h_ = [v for v, l in zip(allv, labs) if not l]
    if np.mean(f_) - np.mean(h_) >= obs:
        exceed += 1
record('paperA.foreign.perm_p', round((exceed + 1) / (NP + 1), 4))
pcts = sorted(100 * np.mean([h < f for h in hs]) for f in fs)
record('paperA.foreign.percentiles', [round(p) for p in pcts])
record('paperA.foreign.n_above_85th_pct', sum(1 for p in pcts if p >= 85))

# ============================================================
# 5. ICONOGRAPHY (Paper A)
# ============================================================
groups = defaultdict(list)
for s, st, t in HOME:
    if s in iconlab:
        lab = iconlab[s]
        k = ('unicorn' if lab.startswith('bull1') else
             'gaur' if lab.startswith(('gaur', 'bull2')) else
             'elephant' if lab.startswith('elep') else
             'zebu' if lab.startswith(('zebu', 'brah')) else None)
        if k:
            groups[k].append(t)
groups = {k: list(dict.fromkeys(v)) for k, v in groups.items()}
for k in groups:
    record(f'paperA.iconography.n_{k}', len(groups[k]))
    record(f'paperA.iconography.meanlen_{k}', round(float(np.mean([len(t) for t in groups[k]])), 3))

def findist(T):
    c = Counter(t[-1] for t in T); n = sum(c.values())
    return {k: v / n for k, v in c.items()}
def jsd(p, q):
    ks = set(p) | set(q)
    P = np.array([p.get(k, 0) for k in ks]); Q = np.array([q.get(k, 0) for k in ks]); M = (P + Q) / 2
    kl = lambda a, b: float((a[a > 0] * np.log2(a[a > 0] / b[a > 0])).sum())
    return 0.5 * kl(P, M) + 0.5 * kl(Q, M)

labels = [k for k in groups for _ in groups[k]]
allt = [t for k in groups for t in groups[k]]
gm = findist(allt)
obs = sum(len(groups[k]) * jsd(findist(groups[k]), gm) for k in groups) / len(allt)
rng = random.Random(5); exceed = 0; NP = 1999
for _ in range(NP):
    rng.shuffle(labels)
    gg = defaultdict(list)
    for lab, t in zip(labels, allt):
        gg[lab].append(t)
    st_ = sum(len(gg[k]) * jsd(findist(gg[k]), gm) for k in gg) / len(allt)
    if st_ >= obs:
        exceed += 1
record('paperA.iconography.omnibus_jsd', round(float(obs), 4))
record('paperA.iconography.omnibus_perm_p', round((exceed + 1) / (NP + 1), 4))

u, g = groups['unicorn'], groups['gaur']
obs2 = jsd(findist(u), findist(g))
pool = u + g; rng = random.Random(2); null = []
for _ in range(2000):
    rng.shuffle(pool)
    null.append(jsd(findist(pool[:len(u)]), findist(pool[len(u):])))
p2 = (sum(1 for x in null if x >= obs2) + 1) / 2001
record('paperA.iconography.unicorn_gaur_jsd', round(float(obs2), 4))
record('paperA.iconography.unicorn_gaur_null_median', round(float(np.median(null)), 4))
record('paperA.iconography.unicorn_gaur_perm_p', round(p2, 4))

lens = {k: [len(t) for t in v] for k, v in groups.items()}
labs2 = [k for k in lens for _ in lens[k]]; allv2 = [x for k in lens for x in lens[k]]
gm2 = np.mean(allv2)
obsF = sum(len(lens[k]) * (np.mean(lens[k]) - gm2) ** 2 for k in lens)
rng = random.Random(6); exc = 0
for _ in range(4999):
    rng.shuffle(labs2)
    gg = defaultdict(list)
    for l_, v_ in zip(labs2, allv2):
        gg[l_].append(v_)
    stF = sum(len(gg[k]) * (np.mean(gg[k]) - gm2) ** 2 for k in gg)
    if stF >= obsF:
        exc += 1
record('paperA.iconography.length_omnibus_perm_p', round((exc + 1) / 5000, 4))

# ============================================================
# 6. CLASS INDUCTION (Paper B) - Mohenjo-daro seals only
# ============================================================
random.seed(11)
M = Mse[:]; random.shuffle(M)
h = int(0.8 * len(M))
Mtr, Mte = M[:h], M[h:]
record('paperB.induction.train_n', len(Mtr))
record('paperB.induction.test_n', len(Mte))

def induce(train):
    freq = Counter(); fin = Counter(); ini = Counter(); nxt = defaultdict(Counter)
    for t in train:
        for s in t:
            freq[s] += 1
        fin[t[-1]] += 1; ini[t[0]] += 1
        for a, b in zip(t, t[1:]):
            nxt[a][b] += 1
    TERM = {s for s in freq if freq[s] >= 10 and fin[s] / freq[s] >= 0.60}
    INIT = {s for s in freq if freq[s] >= 10 and ini[s] / freq[s] >= 0.50 and s not in TERM}
    PRE = {s for s in freq if s not in TERM | INIT and freq[s] >= 10 and sum(nxt[s].values()) >= 8
           and sum(nxt[s][x] for x in TERM) / sum(nxt[s].values()) >= 0.6}
    CONN = {s for s in freq if freq[s] >= 15 and s not in TERM | INIT | PRE
            and fin[s] / freq[s] <= 0.05 and ini[s] / freq[s] <= 0.05}
    return TERM, INIT, PRE, CONN, freq

CL = induce(Mtr)
TERM, INIT, PRE, CONN, freqTr = CL
record('paperB.classes.TERM', sorted(TERM))
record('paperB.classes.INIT', sorted(INIT))
record('paperB.classes.PRE', sorted(PRE))
record('paperB.classes.CONN', sorted(CONN))
V_train = len(freqTr)
record('paperB.classes.V_train', V_train)
record('paperB.classes.CORE_n', V_train - len(TERM) - len(INIT) - len(PRE) - len(CONN))

# Non-recursive terminal-zone rule: licensed iff final, OR penultimate immediately
# before a TERMINAL token that occupies the final position. (Fixed max stack = 2.)
def in_zone(t, i, TT):
    L = len(t)
    if i == L - 1:
        return True
    if i == L - 2 and t[i + 1] in TT and (i + 1) == L - 1:
        return True
    return False

def stats(T, TT, II, PP, CC):
    ok = 0; viol = Counter(); opp = Counter()
    for t in T:
        v = 0; L = len(t)
        for i, s in enumerate(t):
            first = i == 0
            if s in TT:
                opp['R1'] += 1
                if not in_zone(t, i, TT):
                    viol['R1'] += 1; v += 1
            if s in II:
                opp['R2'] += 1
                if not first:
                    viol['R2'] += 1; v += 1
            if s in CC:
                opp['R3'] += 1
                if first or i == L - 1:
                    viol['R3'] += 1; v += 1
            if s in PP and i < L - 1:
                opp['R4'] += 1
                if t[i + 1] not in TT:
                    viol['R4'] += 1; v += 1
        ok += (v == 0)
    micro = 1 - sum(viol.values()) / max(1, sum(opp.values()))
    macro = float(np.mean([1 - viol[r] / max(1, opp[r]) for r in ['R1', 'R2', 'R3', 'R4']]))
    return ok / len(T), micro, macro, dict(viol), dict(opp)

def shuffled(T, seed):
    r = random.Random(seed); out = []
    for t in T:
        x = list(t); r.shuffle(x); out.append(tuple(x))
    return out

c, mi, ma, v, o = stats(Mte, *CL[:4])
record('paperB.primary.compliance', round(c, 4))
record('paperB.primary.conditional_accuracy_micro', round(mi, 4))
record('paperB.primary.conditional_accuracy_macro', round(ma, 4))
for rl in ['R1', 'R2', 'R3', 'R4']:
    record(f'paperB.primary.opp_{rl}', o.get(rl, 0))
    record(f'paperB.primary.viol_{rl}', v.get(rl, 0))
shuf_c = [stats(shuffled(Mte, i), *CL[:4])[0] for i in range(20)]
record('paperB.primary.shuffled_compliance_mean', round(float(np.mean(shuf_c)), 4))

tp_num = sum(1 for t in Mte for i, s in enumerate(t) if s in TERM and in_zone(t, i, TERM))
tp_den = sum(1 for t in Mte for s in t if s in TERM)
record('paperB.primary.terminal_zone_precision_num', tp_num)
record('paperB.primary.terminal_zone_precision_den', tp_den)
term_recall_num = sum(1 for t in Mte if t[-1] in TERM)
record('paperB.primary.terminal_recall_num', term_recall_num)
record('paperB.primary.terminal_recall_den', len(Mte))

# Transfer strata
for nm, T in [('harappa_seals', Hse), ('md_nonseals', Mno)]:
    c2, mi2, ma2, v2, o2 = stats(T, *CL[:4])
    sh = float(np.mean([stats(shuffled(T, i), *CL[:4])[0] for i in range(10)]))
    record(f'paperB.transfer.{nm}.compliance', round(c2, 4))
    record(f'paperB.transfer.{nm}.shuffled_compliance', round(sh, 4))
    record(f'paperB.transfer.{nm}.cond_acc_micro', round(mi2, 4))
    record(f'paperB.transfer.{nm}.cond_acc_macro', round(ma2, 4))
    for rl in ['R1', 'R2', 'R3', 'R4']:
        record(f'paperB.transfer.{nm}.opp_{rl}', o2.get(rl, 0))
        record(f'paperB.transfer.{nm}.viol_{rl}', v2.get(rl, 0))
    tr_num = sum(1 for t in T if t[-1] in TERM)
    record(f'paperB.transfer.{nm}.terminal_recall_num', tr_num)
    record(f'paperB.transfer.{nm}.terminal_recall_den', len(T))

# Containment / retention + downsample
for nm, T in [('harappa_seals', Hse), ('md_nonseals', Mno)]:
    lt = induce(T)[0]
    record(f'paperB.transfer.{nm}.local_TERM', sorted(lt))
    record(f'paperB.transfer.{nm}.containment_num', len(lt & TERM))
    record(f'paperB.transfer.{nm}.containment_den', len(lt))
    record(f'paperB.transfer.{nm}.retention_num', len(lt & TERM))
    record(f'paperB.transfer.{nm}.retention_den', len(TERM))
ns = []
for seed in range(30):
    rr = random.Random(seed); X = Mse[:]; rr.shuffle(X)
    ns.append(len(induce(X[:len(Hse)])[0]))
record('paperB.transfer.downsample_TERM_mean', round(float(np.mean(ns)), 2))
record('paperB.transfer.downsample_TERM_min', min(ns))
record('paperB.transfer.downsample_TERM_max', max(ns))

# ============================================================
# 7. RANDOM-CLASS BASELINE (Paper B) - quantile-matched, 1000 draws
# ============================================================
elig = sorted([s for s in freqTr if freqTr[s] >= 10], key=lambda s: -freqTr[s])
def qmatch(rng):
    used = set(); out = []
    for realset in CL[:4]:
        S = set()
        for s in realset:
            r_ = elig.index(s) if s in elig else rng.randrange(len(elig))
            cands = [x for x in elig[max(0, r_ - 5):r_ + 6] if x not in used]
            pick = rng.choice(cands) if cands else rng.choice([x for x in elig if x not in used] or elig)
            S.add(pick); used.add(pick)
        out.append(S)
    return out
rng = random.Random(1); comp = []; micv = []
for i in range(1000):
    rc = qmatch(rng)
    a, b, _, _, _ = stats(Mte, *rc)
    comp.append(a); micv.append(b)
record('paperB.randomclass.n_draws', 1000)
record('paperB.randomclass.compliance_mean', round(float(np.mean(comp)), 4))
record('paperB.randomclass.compliance_ci_lo', round(float(np.percentile(comp, 2.5)), 4))
record('paperB.randomclass.compliance_ci_hi', round(float(np.percentile(comp, 97.5)), 4))
record('paperB.randomclass.condacc_mean', round(float(np.mean(micv)), 4))
record('paperB.randomclass.condacc_ci_lo', round(float(np.percentile(micv, 2.5)), 4))
record('paperB.randomclass.condacc_ci_hi', round(float(np.percentile(micv, 97.5)), 4))

# ============================================================
# 8. NUMERAL -> COUNTED CONSTRUCTION (Paper B)
# ============================================================
NUMFAM = {3, 4, 5}
COUNTED = {390, 405, 407, 900}
def count_nc(T):
    cnum = 0; pairs = Counter(); txts = set()
    for k_, t in enumerate(T):
        for a, b in zip(t, t[1:]):
            if a in NUMFAM and b in COUNTED:
                cnum += 1; pairs[(a, b)] += 1; txts.add(k_)
    return cnum, pairs, txts
obs3, pairs, txts = count_nc(Mte)
null3 = [count_nc(shuffled(Mte, i))[0] for i in range(2000)]
record('paperB.construction.observed', obs3)
record('paperB.construction.null_mean', round(float(np.mean(null3)), 3))
record('paperB.construction.perm_p', round((sum(1 for x in null3 if x >= obs3) + 1) / 2001, 4))
record('paperB.construction.n_distinct_texts', len(txts))
record('paperB.construction.pair_breakdown', {f"{a}->{b}": c for (a, b), c in pairs.items()})
record('paperB.construction.excess_count', round(obs3 - float(np.mean(null3)), 3))
record('paperB.construction.enrichment_ratio', round(obs3 / max(float(np.mean(null3)), 1e-9), 3))

# ============================================================
# 9. PARAMETER COUNTS + MODEL COMPARISON (Paper B)
# ============================================================
V = len(freqTr)
sign_params = (V - 1) + V * (V - 1)
Vc = {'T': len(TERM), 'I': len(INIT), 'P': len(PRE), 'C': len(CONN)}
Vc['X'] = V - sum(Vc.values())
class_params = (5 - 1) + 5 * (5 - 1) + sum(v_ - 1 for v_ in Vc.values())
record('paperB.params.V', V)
record('paperB.params.sign_model', sign_params)
record('paperB.params.class_model', class_params)
record('paperB.params.class_sizes', Vc)

def fit_sign(tr):
    I = Counter(); Tr = defaultdict(Counter)
    for t in tr:
        I[t[0]] += 1
        for a, b in zip(t, t[1:]):
            Tr[a][b] += 1
    return I, Tr
def xh_sign(mod_, te, Vv, a):
    I, Tr = mod_; It_ = sum(I.values()); tot = n = 0
    for t in te:
        tot += -math.log2((I.get(t[0], 0) + a) / (It_ + a * Vv)); n += 1
        for x, y in zip(t, t[1:]):
            at = sum(Tr.get(x, {}).values()) if x in Tr else 0
            tot += -math.log2(((Tr.get(x, {}).get(y, 0) if x in Tr else 0) + a) / (at + a * Vv)); n += 1
    return tot / n
def make_cf(cl4):
    T_, I_, P_, C_ = cl4
    def cf(s):
        if s in T_: return 'T'
        if s in I_: return 'I'
        if s in P_: return 'P'
        if s in C_: return 'C'
        return 'X'
    return cf
def fit_class(tr, cf):
    CI = Counter(); CT = defaultdict(Counter); W = defaultdict(Counter)
    for t in tr:
        csx = [cf(s) for s in t]
        CI[csx[0]] += 1
        for x, y in zip(csx, csx[1:]):
            CT[x][y] += 1
        for s, cc in zip(t, csx):
            W[cc][s] += 1
    return CI, CT, W
def xh_class(mod_, te, cf, Vv, a):
    CI, CT, W = mod_; CIt = sum(CI.values()); tot = n = 0
    for t in te:
        csx = [cf(s) for s in t]
        for i, (s, cc) in enumerate(zip(t, csx)):
            pc = (CI.get(cc, 0) + a) / (CIt + a * 5) if i == 0 else \
                 (CT.get(csx[i-1], {}).get(cc, 0) + a) / (sum(CT.get(csx[i-1], {}).values()) + a * 5)
            pw = (W.get(cc, {}).get(s, 0) + a) / (sum(W.get(cc, {}).values()) + a * Vv)
            tot += -math.log2(pc * pw); n += 1
    return tot / n

Vfix = len({s for t in Mse for s in t}) + 1
record('paperB.params.Vfix', Vfix)

r = random.Random(3); X = Mtr[:]; r.shuffle(X)
hi = int(0.8 * len(X)); itr, iva = X[:hi], X[hi:]
alphas = [0.05, 0.1, 0.2, 0.5, 1.0]
cf0 = make_cf(CL[:4])
aS = min(alphas, key=lambda a: xh_sign(fit_sign(itr), iva, Vfix, a))
aC = min(alphas, key=lambda a: xh_class(fit_class(itr, cf0), iva, cf0, Vfix, a))
record('paperB.smoothing.tuned_alpha_sign', aS)
record('paperB.smoothing.tuned_alpha_class', aC)
record('paperB.smoothing.equal_alpha_sign_L', round(xh_sign(fit_sign(Mtr), Mte, Vfix, 0.5), 4))
record('paperB.smoothing.equal_alpha_class_L', round(xh_class(fit_class(Mtr, cf0), Mte, cf0, Vfix, 0.5), 4))
record('paperB.smoothing.tuned_sign_L', round(xh_sign(fit_sign(Mtr), Mte, Vfix, aS), 4))
record('paperB.smoothing.tuned_class_L', round(xh_class(fit_class(Mtr, cf0), Mte, cf0, Vfix, aC), 4))

for frac in [0.1, 1.0]:
    ds = []
    for seed in range(30):
        rr = random.Random(300 + seed); X2 = Mse[:]; rr.shuffle(X2)
        hh = int(0.8 * len(X2)); trall, te2 = X2[:hh], X2[hh:]
        tr2 = trall[:max(20, int(frac * len(trall)))]
        cl2 = induce(tr2)[:4]; cf2 = make_cf(cl2)
        ds.append(xh_class(fit_class(tr2, cf2), te2, cf2, Vfix, aC) - xh_sign(fit_sign(tr2), te2, Vfix, aS))
    ds = np.array(ds)
    tag = 'low' if frac == 0.1 else 'full'
    record(f'paperB.crossover.{tag}.delta_median', round(float(np.median(ds)), 4))
    record(f'paperB.crossover.{tag}.delta_ci_lo', round(float(np.percentile(ds, 2.5)), 4))
    record(f'paperB.crossover.{tag}.delta_ci_hi', round(float(np.percentile(ds, 97.5)), 4))
    record(f'paperB.crossover.{tag}.n_favoring_class', int(np.sum(ds < 0)))
    record(f'paperB.crossover.{tag}.n_splits', len(ds))

# ============================================================
# WRITE RESULTS
# ============================================================
with open(os.path.join(OUT, 'results.json'), 'w') as f:
    json.dump(RESULTS, f, indent=1, sort_keys=True, default=str)

with open(os.path.join(OUT, 'results.md'), 'w') as f:
    f.write("# Reproducibility Run Output\n\nGenerated by run_all.py. Every number below is machine-computed from raw data in ../data.\n\n")
    for k in sorted(RESULTS):
        f.write(f"- `{k}` = {RESULTS[k]}\n")

print(f"DONE. {len(RESULTS)} results written to output/results.json and results.md")
